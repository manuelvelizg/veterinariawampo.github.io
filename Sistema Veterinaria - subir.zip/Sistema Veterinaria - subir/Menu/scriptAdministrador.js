/*function showSection(sectionId) {
    // Oculta todas las secciones
    document.getElementById('welcome-section').style.display = 'none';
    document.getElementById('users-section').style.display = 'none';
    document.getElementById('products-section').style.display = 'none';
    document.getElementById('reports-section').style.display = 'none';
    document.getElementById('providers-section').style.display = 'none';
    document.getElementById('logout-section').style.display = 'none';

    // Muestra la sección seleccionada
    document.getElementById(sectionId).style.display = 'block';
  }

  // Puedes establecer el nombre de usuario aquí
  document.getElementById('username').innerText = 'John Doe';

  // Muestra la sección de Bienvenida por defecto
  showSection('welcome-section')*/
  function showSection(sectionId) {
    // Oculta todas las secciones
    document.getElementById('welcome-section').style.display = 'none';
    document.getElementById('users-section').style.display = 'none';
    document.getElementById('products-section').style.display = 'none';
    document.getElementById('reports-section').style.display = 'none';
    document.getElementById('providers-section').style.display = 'none';
    document.getElementById('logout-section').style.display = 'none';

    // Muestra la sección seleccionada
    document.getElementById(sectionId).style.display = 'block';
  }

// Puedes establecer el nombre de usuario aquí
document.getElementById('username').innerText = response.username;

  // Muestra la sección de Bienvenida por defecto
  showSection('welcome-section');