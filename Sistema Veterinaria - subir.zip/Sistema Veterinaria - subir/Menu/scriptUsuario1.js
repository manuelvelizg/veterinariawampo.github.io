function mostrarContenido(seccion) {
    // Ocultar todas las secciones
    document.getElementById('tienda').style.display = 'none';
    document.getElementById('adopcion').style.display = 'none';
    document.getElementById('citas').style.display = 'none';

    // Mostrar la sección seleccionada
    document.getElementById(seccion).style.display = 'block';
  }