<?php
print "Usted ha accedido al menú del Usuario1";
?>