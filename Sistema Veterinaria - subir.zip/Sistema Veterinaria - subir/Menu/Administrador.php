<?php

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinaria Wampo</title>
    <link rel="stylesheet" href="EstiloAdministrador.css">
    <script src="scriptAdministrador.js" defer></script>
</head>

<body>
    <div id="dashboard">
        <div id="sidebar">
            <div class="menu-item" onclick="showSection('welcome-section')">Bienvenida</div>
            <div class="menu-item" onclick="showSection('users-section')">Usuarios</div>
            <div class="menu-item" onclick="showSection('products-section')">Productos</div>
            <div class="menu-item" onclick="showSection('reports-section')">Reportes</div>
            <div class="menu-item" onclick="showSection('providers-section')">Proveedores</div>
            <div class="menu-item" onclick="showSection('logout-section')">Salir</div>
        </div>

        <div id="main-content">
            <div id="welcome-section">
                <h2>Bienvenido, <span id="username">Carlos Manuel</span>!</h2>
            </div>

            <div id="users-section">
                <h2>Sección de Usuarios</h2>
                <!-- Contenido de la sección de Usuarios -->
            </div>

            <div id="products-section">
                <h2>Sección de Productos</h2>
                <!-- Contenido de la sección de Productos -->
            </div>

            <div id="reports-section">
                <h2>Sección de Reportes</h2>
                <!-- Contenido de la sección de Reportes -->
            </div>

            <div id="providers-section">
                <h2>Sección de Proveedores</h2>
                <!-- Contenido de la sección de Proveedores -->
            </div>

            <div id="logout-section">
                <h2>Salir</h2>
                <!-- Contenido de la sección de Salir -->
            </div>
        </div>
    </div>
</body>

</html>