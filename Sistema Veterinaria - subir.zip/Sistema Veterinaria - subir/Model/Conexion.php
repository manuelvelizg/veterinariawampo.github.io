<?php

/*class Conexion {
    private $servername = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "bdveterinaria_wampo";
    public $conn;

    public function __construct() {
        // Realiza la conexión a la base de datos
        $this->conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);

        // Verifica la conexión
        if ($this->conn->connect_error) {
            die("La conexión falló: " . $this->conn->connect_error);
        }
    }

    public function autenticarUsuario($username, $password) {
        // Consulta SQL para verificar la autenticación
        $sql = "SELECT * FROM users_login WHERE User='$username' AND password='$password'";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            // El usuario se autenticó correctamente, devuelve el rol
            $row = $result->fetch_assoc();
            $role = $row['User'];

            return $role;
        } else {
            // Autenticación fallida, devuelve false
            return false;
        }
    }

    public function cerrarConexion() {
        // Cierra la conexión a la base de datos
        $this->conn->close();
    }
}

// Uso de la clase
$conexion = new Conexion();
$username = $_POST['username'];
$password = $_POST['password'];

$role = $conexion->autenticarUsuario($username, $password);

if ($role !== false) {
    // El usuario se autenticó correctamente, redirige según el rol
    switch ($role) {
        case 'admin':
            print "Has inciado como administrador";
            //header("Location: /menu_admin.php");
            break;
        case 'usuario':
            print "Has iniciado como usuario";
            //header("Location: /menu_usuario.php");
            break;
        // Agrega más casos según tus roles
        default:
            //echo "Rol no reconocido";
    }
} else {
    // Autenticación fallida, redirige a la página de inicio de sesión
    //header("Location: Validacion/Acceder.php");
    print "Hubo un error";
}

$conexion->cerrarConexion();
*/
?>