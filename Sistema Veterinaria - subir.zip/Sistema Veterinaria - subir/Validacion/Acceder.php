<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinaria Wampo</title>
    <link rel="stylesheet" href="EstiloAcceder.css">
    <script src="script.js" defer></script>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <link rel="icon" href="/Modulos/Iconos/logoWampo.ico">
    <script src="https://crypto-js.googlecode.com/svn/tags/3.1.2/build/rollups/sha256.js"></script>

    <!--<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>-->
</head>

<body>

    <div id="error-message" style="color: red;"></div>
    <div id="loader-wrapper">
        <div id="loader"></div>
    </div>

    <div id="loading-circle"></div>

    <div id="login-formulario">
        <div class="login-container">
            <h2>Iniciar Sesión</h2>
            <form class="login-form" action="ValidacionAcceso.php" method="POST" onsubmit="return loginUser()">
                <div class="form-group">
                    <strong><label for="email">Correo Electrónico:</label></strong>
                    <input type="email" id="email" name="email" placeholder="Ingrese correo electrónico" required>
                </div>
                <div class="form-group">
                    <strong><label for="password">Contraseña:</label></strong>
                    <input type="password" id="password" name="password" placeholder="Ingrese contraseña" required>
                </div>
                <div class="form-group">
                    <a href="Acceder.php"><input type="submit" value="Iniciar Sesión" name="submit" id="login-acceder"></a>
                </div>
            </form>
            <div class="form-group">
                <a href="/Modulos/Inicio.php"><button type="button">Atrás</button></a>
            </div>
            <div class="signup-link">
                ¿Eres nuevo? <a href="Registrate.php">Regístrate aquí</a>
            </div>
            <div class="forgot-password-link">
                <a href="RecuperarContrasena.php">¿Olvidaste tu contraseña?</a>
            </div>
        </div>
    </div>

</body>



</html>