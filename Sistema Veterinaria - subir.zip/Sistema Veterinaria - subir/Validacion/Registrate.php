<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinaria Wampo</title>
    <link rel="stylesheet" href="EstiloRegistrate.css">
    <script src="scriptRegistrate.js" defer></script>
</head>

<body>

    <form id="registrationForm">
        <h2>Regístrate</h2>
        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" placeholder="Ingrese Dni" required>

        <label for="nombres">Nombres:</label>
        <input type="text" id="nombres" name="nombres" placeholder="Ingrese Nombres" required>

        <label for="apellidos">Apellidos:</label>
        <input type="text" id="apellidos" name="apellidos" placeholder="Ingrese Apellidos" required>

        <label for="fechaNacimiento">Fecha de Nacimiento:</label>
        <input type="date" id="fechaNacimiento" name="fechaNacimiento" required>

        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" placeholder="Ingrese Dirección" required>

        <label for="correo">Correo Electrónico:</label>
        <input type="email" id="correo" name="correo" placeholder="Ingrese Correo Electrónico" required>

        <label for="password">Contraseña:</label>
        <input type="password" id="password" name="password" placeholder="Ingrese Contraseña" required>

        <label for="confirmPassword">Confirmar Contraseña:</label>
        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Ingrese Contraseña" required>

        <button type="button" onclick="register()">Registrarse</button>

        <button id="backButton" type="button">Atrás</button>
    </form>

    <div id="mensajeRegistro" style="text-align: center;"></div>

</body>

</html>