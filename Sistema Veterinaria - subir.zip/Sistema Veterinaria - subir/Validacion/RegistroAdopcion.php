<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Veterinaria Wampo</title>
    <link rel="stylesheet" href="EstiloRegistroAdopción.css">
    <link rel="icon" href="/Modulos/Iconos/logoWampo.ico">
</head>

<body>
    <form id="form-adopcion" action="#" method="post">
        <h2>Adopción</h2>
        <label for="dni">DNI:</label>
        <input type="text" id="dni" name="dni" placeholder="Ingrese Dni" required>

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" placeholder="Ingrese Nombres" required>

        <label for="apellidos">Apellidos:</label>
        <input type="text" id="apellidos" name="apellidos" placeholder="Ingrese Apellidos" required>

        <label for="celular">Celular:</label>
        <input type="tel" id="celular" name="celular" placeholder="Ingrese Celular" required>

        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" placeholder="Ingrese Dirección" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" placeholder="Ingrese Email" required>

        <button type="submit">Adoptar</button>
        <button type="button" class="back">Atrás</button>
    </form>
</body>

</html>