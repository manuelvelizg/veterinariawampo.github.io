<?php
print "Hola Mundo";
?>