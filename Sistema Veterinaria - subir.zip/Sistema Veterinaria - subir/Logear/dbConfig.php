<?php
    $mysqli = new mysqli("localhost", "root", "", "bdveterinaria_wampo");
?>