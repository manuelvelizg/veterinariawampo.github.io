<?php
    $mysqli = new mysqli("localhost", "root", "", "formdb");
?>