# Registro de Usuario, Login y Cambio de Contraseña en PHP y MySQL
<img src="https://i0.wp.com/www.configuroweb.com/wp-content/uploads/2020/06/Registro-de-Usuario-Login-y-Cambio-de-Contrase%C3%B1a-en-PHP-y-MySQL.png?resize=800%2C500&ssl=1">
Todos los detalles sobre esta aplicación los puedes validar en el siguiente enlace:

<a href="https://www.configuroweb.com/registro-de-usuario-login-y-cambio-de-contrasena-en-php-y-mysql/">Registro de Usuario, Login y Cambio de Contraseña en PHP y MySQL</a>
