<h2><br>Web Site Administration<br>
</h2> <p>Please log in below</p> 
<form   action="validate.php" method="post"> 
<b>User Name:</b> 
<br> <input type="text" size="20" name="username">
<br> <br> <b>Password:</b> 
<br><input type="password" size="20" name="password"> <br>
<br> <input type="submit" value="login"> </form>